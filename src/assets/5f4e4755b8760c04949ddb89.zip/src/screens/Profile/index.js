import React from 'react';
import { Text } from 'react-native';
import { Container } from './styles';

export default () => {
    return (
        <Container>
            <Text>Profile</Text>
        </Container>
    );
}